-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : sam. 27 nov. 2021 à 12:28
-- Version du serveur :  5.7.31
-- Version de PHP : 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `league1`
--

-- --------------------------------------------------------

--
-- Structure de la table `classement_grpa`
--

DROP TABLE IF EXISTS `classement_grpa`;
CREATE TABLE IF NOT EXISTS `classement_grpa` (
  `MJ` int(2) NOT NULL,
  `MG` int(2) NOT NULL,
  `MN` int(2) NOT NULL,
  `MP` int(2) NOT NULL,
  `BP` int(2) NOT NULL,
  `BC` int(2) NOT NULL,
  `Diff` int(2) NOT NULL,
  `Point` int(2) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `classement_grpb`
--

DROP TABLE IF EXISTS `classement_grpb`;
CREATE TABLE IF NOT EXISTS `classement_grpb` (
  `MJ` int(2) NOT NULL,
  `MG` int(2) NOT NULL,
  `MN` int(2) NOT NULL,
  `MP` int(2) NOT NULL,
  `BP` int(2) NOT NULL,
  `BC` int(2) NOT NULL,
  `Diff` int(2) NOT NULL,
  `Point` int(2) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `classement_grpb`
--

INSERT INTO `classement_grpb` (`MJ`, `MG`, `MN`, `MP`, `BP`, `BC`, `Diff`, `Point`) VALUES
(1, 0, 0, 0, 0, 0, 0, 0),
(1, 0, 0, 0, 0, 0, 0, 0),
(1, 0, 0, 0, 0, 0, 0, 0),
(1, 0, 0, 0, 0, 0, 0, 0),
(1, 0, 0, 0, 0, 0, 0, 0),
(1, 0, 0, 0, 0, 0, 0, 0),
(1, 0, 0, 0, 0, 0, 0, 0),
(1, 0, 0, 0, 0, 0, 0, 0),
(1, 0, 0, 0, 0, 0, 0, 0),
(1, 0, 0, 0, 0, 0, 0, 0),
(1, 0, 0, 0, 0, 0, 0, 0),
(1, 0, 0, 0, 0, 0, 0, 0),
(1, 0, 0, 0, 0, 0, 0, 0),
(1, 0, 0, 0, 0, 0, 0, 0),
(1, 0, 0, 0, 0, 0, 0, 0),
(1, 0, 0, 0, 0, 0, 0, 0),
(1, 0, 0, 0, 0, 0, 0, 0),
(1, 0, 0, 0, 0, 0, 0, 0),
(1, 0, 0, 0, 0, 0, 0, 0),
(1, 0, 0, 0, 0, 0, 0, 0),
(1, 0, 0, 0, 0, 0, 0, 0),
(1, 0, 0, 0, 0, 0, 0, 0),
(1, 0, 0, 0, 0, 0, 0, 0),
(1, 0, 0, 0, 0, 0, 0, 0),
(1, 0, 0, 0, 0, 0, 0, 0),
(1, 0, 0, 0, 0, 0, 0, 0),
(1, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Structure de la table `match_pam`
--

DROP TABLE IF EXISTS `match_pam`;
CREATE TABLE IF NOT EXISTS `match_pam` (
  `nom_equipe_1` text NOT NULL,
  `nom_equipe_2` text NOT NULL,
  `score_1` int(11) NOT NULL,
  `score_2` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

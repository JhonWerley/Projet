<?php
require('security.php');
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8"/>
        <link href="championnat.css" rel="stylesheet"/>
        <title>Accueil Championnat</title>
    </head>
    <body>
       <section class="acc">
           <a href="tirage.php"> <p> Tirages </p></a>
           
        </section> 
        <!-- <div class="logout">
           <a href="logout.php"><p class="deco"> Logout </p></a>
        </div> -->
    </body>
</html>
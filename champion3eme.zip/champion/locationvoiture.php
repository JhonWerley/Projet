<?php


?>

<!-- <script type="text/javascript">
	var i =0;//point de demrage
	var image=[];
	var time =3000;
	//liste imege
	images[0]='image1.jpg';
	images[1]='image2.jpg';
	images[2]='image3.jpg';
	images[3]='image4.jpg';

	//change image
	function fonctionChangeImage() {
		document.slide.src=image[i];

		if (i<image.length -1) {
			i++;
		}	else{
			i=0;
		}

		setTimeout("fonctionChangeImage()", time);
	}
	window.onload	= fonctionChangeImage;

</script> -->

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title> location voiture </title>
	<link rel="stylesheet" type="text/css" href="locations.css">
	<script type="text/javascript"></script>
</head>
<div class="header">
  	<button class="btn"> Logo car_Location </button>		
  	<nav>
  		<ul>
  			<li class="nav"> <a href="locationvoiture.php"> Accueil </a> </li>
  			<li class="nav"> <a href="listvoiture.php"> Voiture </a> </li>
  			<li class="nav"> <a href="rechercheVoiture.php"> Reservation </a> </li>
  			<li class="login1"> <a href="rechercheVoiture.php"> <span class="image"><img src="connect.png" width="20" height="20"> login </a> </li>
  			<li class="nav"> <input type="search" name="recherche"></li>
  		</ul>
   	</nav>
  </div>
<body>
  
  <!-- <img name="slide" src="image1v.jpg" width="100%" height="620"> -->
  <div>
  	<h2 class="titreAccueil"> Recent car location </h2>
  </div>
  <!-- <div class="divGenerale">
  	<div class="petitdivFlot">
  		<div class="div1">
  			<h3> Bienvenue dans location voiture </h3>
  			<p> loren a site location voiture, faire votre reservation en ligne<br/> nous avons toute les nouveau machine modele 2021<br/>n'hesiter pas a nous contacter </p>
  		</div>

  		<div class="div2">
  			
  		</div>
  		
  	</div>
  	
  </div> -->
</body>
</html>